package com.quiz;

import com.quiz.service.UserService;
import com.quiz.service.QuizService;
import com.quiz.util.DatabaseUtil;

/**
 * Console test application to verify core functionality
 * without requiring JavaFX GUI
 */
public class TestConsole {
    
    public static void main(String[] args) {
        try {
            System.out.println("=== Quiz Application Core Test ===");
            
            // Initialize database
            System.out.println("Initializing database...");
            DatabaseUtil.initializeDatabase();
            System.out.println("✓ Database initialized successfully");
            
            // Test user service
            System.out.println("Testing user service...");
            UserService userService = new UserService();
            
            // Test quiz service
            System.out.println("Testing quiz service...");
            QuizService quizService = new QuizService();
            
            System.out.println("✓ All services initialized successfully");
            System.out.println("✓ Core application functionality is working");
            System.out.println("\nThe application is ready to run with a GUI environment.");
            
        } catch (Exception e) {
            System.err.println("✗ Error during testing: " + e.getMessage());
            e.printStackTrace();
        }
    }
}