package com.quiz.controller;

import com.quiz.model.QuizAttempt;
import com.quiz.service.QuizService;
import com.quiz.util.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Controller for the leaderboard screen
 */
public class LeaderboardController {
    
    @FXML private TableView<QuizAttempt> leaderboardTableView;
    @FXML private TableColumn<QuizAttempt, String> rankColumn;
    @FXML private TableColumn<QuizAttempt, String> usernameColumn;
    @FXML private TableColumn<QuizAttempt, String> quizTitleColumn;
    @FXML private TableColumn<QuizAttempt, Integer> scoreColumn;
    @FXML private TableColumn<QuizAttempt, Integer> totalColumn;
    @FXML private TableColumn<QuizAttempt, String> percentageColumn;
    @FXML private TableColumn<QuizAttempt, String> dateColumn;
    @FXML private Button backToDashboardButton;
    
    private QuizService quizService = new QuizService();
    
    @FXML
    private void initialize() {
        setupTable();
        loadLeaderboard();
    }
    
    private void setupTable() {
        // Setup table columns
        rankColumn.setCellValueFactory(cellData -> {
            int index = leaderboardTableView.getItems().indexOf(cellData.getValue()) + 1;
            return new javafx.beans.property.SimpleStringProperty("#" + index);
        });
        
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        quizTitleColumn.setCellValueFactory(new PropertyValueFactory<>("quizTitle"));
        scoreColumn.setCellValueFactory(new PropertyValueFactory<>("score"));
        totalColumn.setCellValueFactory(new PropertyValueFactory<>("totalQuestions"));
        
        percentageColumn.setCellValueFactory(cellData -> {
            double percentage = cellData.getValue().getPercentage();
            return new javafx.beans.property.SimpleStringProperty(String.format("%.1f%%", percentage));
        });
        
        dateColumn.setCellValueFactory(cellData -> {
            if (cellData.getValue().getCompletedAt() != null) {
                String formattedDate = cellData.getValue().getCompletedAt()
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
                return new javafx.beans.property.SimpleStringProperty(formattedDate);
            }
            return new javafx.beans.property.SimpleStringProperty("");
        });
        
        // Style the rank column to highlight top positions
        rankColumn.setCellFactory(column -> new TableCell<QuizAttempt, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(item);
                    if (item.equals("#1")) {
                        setStyle("-fx-background-color: gold; -fx-font-weight: bold;");
                    } else if (item.equals("#2")) {
                        setStyle("-fx-background-color: silver; -fx-font-weight: bold;");
                    } else if (item.equals("#3")) {
                        setStyle("-fx-background-color: #cd7f32; -fx-font-weight: bold;");
                    } else {
                        setStyle("");
                    }
                }
            }
        });
    }
    
    private void loadLeaderboard() {
        List<QuizAttempt> leaderboard = quizService.getLeaderboard();
        leaderboardTableView.setItems(FXCollections.observableArrayList(leaderboard));
        
        if (leaderboard.isEmpty()) {
            leaderboardTableView.setPlaceholder(new Label("No quiz attempts yet"));
        }
    }
    
    @FXML
    private void handleBackToDashboard() {
        SceneManager.switchScene("dashboard");
    }
}
