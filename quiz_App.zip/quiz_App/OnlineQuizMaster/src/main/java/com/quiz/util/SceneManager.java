package com.quiz.util;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Scene manager for handling navigation between different screens
 */
public class SceneManager {
    private static Stage primaryStage;
    private static Map<String, Scene> scenes = new HashMap<>();
    
    public static void initialize(Stage stage) {
        primaryStage = stage;
    }
    
    /**
     * Switch to a different scene
     */
    public static void switchScene(String sceneName) {
        try {
            Scene scene = scenes.get(sceneName);
            if (scene == null) {
                scene = loadScene(sceneName);
                scenes.put(sceneName, scene);
            }
            primaryStage.setScene(scene);
        } catch (IOException e) {
            System.err.println("Error switching to scene: " + sceneName);
            e.printStackTrace();
        }
    }
    
    /**
     * Load a scene from FXML file
     */
    private static Scene loadScene(String sceneName) throws IOException {
        String fxmlPath = "/fxml/" + sceneName + ".fxml";
        FXMLLoader loader = new FXMLLoader(SceneManager.class.getResource(fxmlPath));
        Parent root = loader.load();
        return new Scene(root);
    }
    
    /**
     * Clear cached scenes (useful for refreshing data)
     */
    public static void clearCache() {
        scenes.clear();
    }
    
    public static Stage getPrimaryStage() {
        return primaryStage;
    }
}
