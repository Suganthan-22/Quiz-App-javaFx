package com.quiz.controller;

import com.quiz.model.User;
import com.quiz.service.UserService;
import com.quiz.util.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.control.*;

/**
 * Controller for the login screen
 */
public class LoginController {
    
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;
    @FXML private Button loginButton;
    @FXML private Button registerButton;
    
    private UserService userService = new UserService();
    public static User currentUser;
    
    @FXML
    private void initialize() {
        errorLabel.setVisible(false);
    }
    
    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();
        
        if (username.isEmpty() || password.isEmpty()) {
            showError("Please enter both username and password");
            return;
        }
        
        User user = userService.authenticateUser(username, password);
        if (user != null) {
            currentUser = user;
            SceneManager.clearCache(); // Clear cache to refresh data
            SceneManager.switchScene("dashboard");
        } else {
            showError("Invalid username or password");
        }
    }
    
    @FXML
    private void handleRegister() {
        SceneManager.switchScene("register");
    }
    
    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }
}
