package com.quiz;

import com.quiz.util.DatabaseUtil;
import com.quiz.util.SceneManager;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Main application class for the Quiz Application
 * Initializes the database and launches the JavaFX application
 */
public class QuizApplication extends Application {
    
    @Override
    public void init() throws Exception {
        super.init();
        // Initialize database on application startup
        DatabaseUtil.initializeDatabase();
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        SceneManager.initialize(primaryStage);
        SceneManager.switchScene("login");
        
        primaryStage.setTitle("Quiz Application");
        primaryStage.setResizable(true);
        primaryStage.setMinWidth(800);
        primaryStage.setMinHeight(600);
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
