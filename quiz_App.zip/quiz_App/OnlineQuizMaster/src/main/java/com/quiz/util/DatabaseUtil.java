package com.quiz.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Database utility class for managing SQLite database connections and initialization
 */
public class DatabaseUtil {
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/quiz_app?useSSL=false";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Suganth@2212";
    
    /**
     * Get a connection to the SQLite database
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL, DB_USER, DB_PASSWORD);
    }
    
    /**
     * Initialize the database by creating necessary tables
     */
    public static void initializeDatabase() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            
            // Create users table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    username VARCHAR(255) UNIQUE NOT NULL,
                    email VARCHAR(255) UNIQUE NOT NULL,
                    password_hash VARCHAR(255) NOT NULL,
                    is_admin BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """);
            
            // Create quizzes table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS quizzes (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    title VARCHAR(255) NOT NULL,
                    description TEXT,
                    category VARCHAR(255) NOT NULL,
                    created_by INT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (created_by) REFERENCES users(id)
                )
            """);
            
            // Create questions table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS questions (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    quiz_id INT NOT NULL,
                    question_text TEXT NOT NULL,
                    option_a VARCHAR(255) NOT NULL,
                    option_b VARCHAR(255) NOT NULL,
                    option_c VARCHAR(255) NOT NULL,
                    option_d VARCHAR(255) NOT NULL,
                    correct_answer CHAR(1) NOT NULL,
                    points INT DEFAULT 1,
                    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
                )
            """);
            
            // Create quiz_attempts table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS quiz_attempts (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    user_id INT NOT NULL,
                    quiz_id INT NOT NULL,
                    score INT NOT NULL,
                    total_questions INT NOT NULL,
                    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id),
                    FOREIGN KEY (quiz_id) REFERENCES quizzes(id)
                )
            """);
            
            // Create default admin user if not exists
            stmt.execute("""
                INSERT IGNORE INTO users (username, email, password_hash, is_admin) 
                VALUES ('admin', 'admin@quiz.com', '$2a$10$8K1p/a0dUrKHOxCgvKw8xOxX/mF8vj8BUQtBxzxvXqjZ8w8xYk5Xi', TRUE)
            """);
            
            System.out.println("Database initialized successfully");
            
        } catch (SQLException e) {
            System.err.println("Error initializing database: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
