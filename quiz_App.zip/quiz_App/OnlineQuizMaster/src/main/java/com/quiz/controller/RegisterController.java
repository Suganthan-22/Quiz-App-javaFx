package com.quiz.controller;

import com.quiz.service.UserService;
import com.quiz.util.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.control.*;

/**
 * Controller for the registration screen
 */
public class RegisterController {
    
    @FXML private TextField usernameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private Label errorLabel;
    @FXML private Label successLabel;
    @FXML private Button registerButton;
    @FXML private Button backToLoginButton;
    @FXML private ComboBox<String> roleComboBox;
    
    private UserService userService = new UserService();
    
    @FXML
    private void initialize() {
        errorLabel.setVisible(false);
        successLabel.setVisible(false);
    }
    
    @FXML
    private void handleRegister() {
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();
        String role = roleComboBox.getValue();
        
        // Validation
        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || role == null || role.isEmpty()) {
            showError("All fields are required");
            return;
        }
        
        if (username.length() < 3) {
            showError("Username must be at least 3 characters long");
            return;
        }
        
        if (!isValidEmail(email)) {
            showError("Please enter a valid email address");
            return;
        }
        
        if (password.length() < 6) {
            showError("Password must be at least 6 characters long");
            return;
        }
        
        if (!password.equals(confirmPassword)) {
            showError("Passwords do not match");
            return;
        }
        
        // Check if username or email already exists
        if (userService.usernameExists(username)) {
            showError("Username already exists");
            return;
        }
        
        if (userService.emailExists(email)) {
            showError("Email already exists");
            return;
        }
        
        // Register user
        boolean success = userService.registerUser(username, email, password, role);
        if (success) {
            showSuccess("Registration successful! You can now login.");
            clearFields();
        } else {
            showError("Registration failed. Please try again.");
        }
    }
    
    @FXML
    private void handleBackToLogin() {
        SceneManager.switchScene("login");
    }
    
    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
        successLabel.setVisible(false);
    }
    
    private void showSuccess(String message) {
        successLabel.setText(message);
        successLabel.setVisible(true);
        errorLabel.setVisible(false);
    }
    
    private void clearFields() {
        usernameField.clear();
        emailField.clear();
        passwordField.clear();
        confirmPasswordField.clear();
    }
    
    private boolean isValidEmail(String email) {
        return email.contains("@") && email.contains(".") && email.length() > 5;
    }
}
