package com.quiz.controller;

import java.time.format.DateTimeFormatter;
import java.util.List;

import com.quiz.model.Quiz;
import com.quiz.model.QuizAttempt;
import com.quiz.service.QuizService;
import com.quiz.util.SceneManager;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * Controller for the main dashboard screen
 */
public class DashboardController {
    
    @FXML private Label welcomeLabel;
    @FXML private ListView<Quiz> quizListView;
    @FXML private TableView<QuizAttempt> historyTableView;
    @FXML private TableColumn<QuizAttempt, String> quizTitleColumn;
    @FXML private TableColumn<QuizAttempt, Integer> scoreColumn;
    @FXML private TableColumn<QuizAttempt, Integer> totalColumn;
    @FXML private TableColumn<QuizAttempt, String> percentageColumn;
    @FXML private TableColumn<QuizAttempt, String> dateColumn;
    @FXML private Button takeQuizButton;
    @FXML private Button adminPanelButton;
    @FXML private Button leaderboardButton;
    @FXML private Button logoutButton;
    
    private QuizService quizService = new QuizService();
    
    @FXML
    private void initialize() {
        setupUI();
        loadQuizzes();
        loadUserHistory();
    }
    
    private void setupUI() {
        // Set welcome message
        welcomeLabel.setText("Welcome, " + LoginController.currentUser.getUsername() + "!");
        
        String role = LoginController.currentUser.getRole();
        // Show admin panel button only for admin users
        adminPanelButton.setVisible("admin".equals(role));
        // Only students can take quizzes
        takeQuizButton.setVisible("student".equals(role));
        // Teachers can see quizzes but not take them
        if ("teacher".equals(role)) {
            takeQuizButton.setVisible(false);
        }
        
        // Setup history table columns
        quizTitleColumn.setCellValueFactory(new PropertyValueFactory<>("quizTitle"));
        scoreColumn.setCellValueFactory(new PropertyValueFactory<>("score"));
        totalColumn.setCellValueFactory(new PropertyValueFactory<>("totalQuestions"));
        
        percentageColumn.setCellValueFactory(cellData -> {
            double percentage = cellData.getValue().getPercentage();
            return new javafx.beans.property.SimpleStringProperty(String.format("%.1f%%", percentage));
        });
        
        dateColumn.setCellValueFactory(cellData -> {
            if (cellData.getValue().getCompletedAt() != null) {
                String formattedDate = cellData.getValue().getCompletedAt()
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
                return new javafx.beans.property.SimpleStringProperty(formattedDate);
            }
            return new javafx.beans.property.SimpleStringProperty("");
        });
        
        // Enable quiz selection
        quizListView.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> takeQuizButton.setDisable(newValue == null)
        );
        
        takeQuizButton.setDisable(true);
    }
    
    private void loadQuizzes() {
        List<Quiz> quizzes = quizService.getAllQuizzes();
        quizListView.setItems(FXCollections.observableArrayList(quizzes));
        
        if (quizzes.isEmpty()) {
            quizListView.setPlaceholder(new Label("No quizzes available"));
        }
    }
    
    private void loadUserHistory() {
        List<QuizAttempt> history = quizService.getUserQuizHistory(LoginController.currentUser.getId());
        historyTableView.setItems(FXCollections.observableArrayList(history));
        
        if (history.isEmpty()) {
            historyTableView.setPlaceholder(new Label("No quiz attempts yet"));
        }
    }
    
    @FXML
    private void handleTakeQuiz() {
        Quiz selectedQuiz = quizListView.getSelectionModel().getSelectedItem();
        if (selectedQuiz != null) {
            QuizController.setSelectedQuiz(selectedQuiz);
            SceneManager.switchScene("quiz");
        }
    }
    
    @FXML
    private void handleAdminPanel() {
        if (LoginController.currentUser.isAdmin()) {
            SceneManager.switchScene("admin");
        }
    }
    
    @FXML
    private void handleLeaderboard() {
        SceneManager.switchScene("leaderboard");
    }
    
    @FXML
    private void handleLogout() {
        LoginController.currentUser = null;
        SceneManager.clearCache();
        SceneManager.switchScene("login");
    }
}
