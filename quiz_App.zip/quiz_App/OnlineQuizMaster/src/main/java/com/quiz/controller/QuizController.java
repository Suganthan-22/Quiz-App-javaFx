package com.quiz.controller;

import com.quiz.model.Question;
import com.quiz.model.Quiz;
import com.quiz.model.QuizAttempt;
import com.quiz.service.QuizService;
import com.quiz.util.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

import java.util.List;

/**
 * Controller for taking quizzes
 */
public class QuizController {
    
    @FXML private Label quizTitleLabel;
    @FXML private Label questionCountLabel;
    @FXML private Label questionTextLabel;
    @FXML private RadioButton optionA;
    @FXML private RadioButton optionB;
    @FXML private RadioButton optionC;
    @FXML private RadioButton optionD;
    @FXML private ToggleGroup optionsGroup;
    @FXML private Button nextButton;
    @FXML private Button finishButton;
    @FXML private Button backToDashboardButton;
    @FXML private Label feedbackLabel;
    @FXML private Label scoreLabel;
    @FXML private VBox quizContainer;
    @FXML private VBox resultsContainer;
    
    private static Quiz selectedQuiz;
    private List<Question> questions;
    private int currentQuestionIndex = 0;
    private int score = 0;
    private QuizService quizService = new QuizService();
    private boolean quizCompleted = false;
    
    public static void setSelectedQuiz(Quiz quiz) {
        selectedQuiz = quiz;
    }
    
    @FXML
    private void initialize() {
        if (selectedQuiz == null) {
            showError("No quiz selected");
            return;
        }
        
        setupUI();
        loadQuiz();
        showCurrentQuestion();
    }
    
    private void setupUI() {
        optionsGroup = new ToggleGroup();
        optionA.setToggleGroup(optionsGroup);
        optionB.setToggleGroup(optionsGroup);
        optionC.setToggleGroup(optionsGroup);
        optionD.setToggleGroup(optionsGroup);
        
        feedbackLabel.setVisible(false);
        resultsContainer.setVisible(false);
        finishButton.setVisible(false);
        
        quizTitleLabel.setText(selectedQuiz.getTitle());
    }
    
    private void loadQuiz() {
        questions = quizService.getQuizQuestions(selectedQuiz.getId());
        if (questions.isEmpty()) {
            showError("This quiz has no questions");
            return;
        }
    }
    
    private void showCurrentQuestion() {
        if (currentQuestionIndex >= questions.size()) {
            finishQuiz();
            return;
        }
        
        Question question = questions.get(currentQuestionIndex);
        
        questionCountLabel.setText("Question " + (currentQuestionIndex + 1) + " of " + questions.size());
        questionTextLabel.setText(question.getQuestionText());
        
        optionA.setText("A) " + question.getOptionA());
        optionB.setText("B) " + question.getOptionB());
        optionC.setText("C) " + question.getOptionC());
        optionD.setText("D) " + question.getOptionD());
        
        // Clear previous selection
        optionsGroup.selectToggle(null);
        feedbackLabel.setVisible(false);
        
        // Show finish button on last question
        if (currentQuestionIndex == questions.size() - 1) {
            nextButton.setVisible(false);
            finishButton.setVisible(true);
        }
    }
    
    @FXML
    private void handleNext() {
        if (processAnswer()) {
            currentQuestionIndex++;
            showCurrentQuestion();
        }
    }
    
    @FXML
    private void handleFinish() {
        if (processAnswer()) {
            finishQuiz();
        }
    }
    
    private boolean processAnswer() {
        RadioButton selectedOption = (RadioButton) optionsGroup.getSelectedToggle();
        if (selectedOption == null) {
            showFeedback("Please select an answer", false);
            return false;
        }
        
        Question question = questions.get(currentQuestionIndex);
        char selectedAnswer = getSelectedAnswer(selectedOption);
        boolean isCorrect = selectedAnswer == question.getCorrectAnswer();
        
        if (isCorrect) {
            score += question.getPoints();
            showFeedback("Correct! +" + question.getPoints() + " points", true);
        } else {
            showFeedback("Incorrect. The correct answer was " + question.getCorrectAnswer() + 
                        ") " + question.getOptionByLetter(question.getCorrectAnswer()), false);
        }
        
        return true;
    }
    
    private char getSelectedAnswer(RadioButton selectedOption) {
        if (selectedOption == optionA) return 'A';
        if (selectedOption == optionB) return 'B';
        if (selectedOption == optionC) return 'C';
        if (selectedOption == optionD) return 'D';
        return ' ';
    }
    
    private void showFeedback(String message, boolean isCorrect) {
        feedbackLabel.setText(message);
        feedbackLabel.setStyle(isCorrect ? "-fx-text-fill: green;" : "-fx-text-fill: red;");
        feedbackLabel.setVisible(true);
    }
    
    private void finishQuiz() {
        quizCompleted = true;
        
        // Save quiz attempt
        QuizAttempt attempt = new QuizAttempt(
            LoginController.currentUser.getId(),
            selectedQuiz.getId(),
            score,
            questions.size()
        );
        quizService.saveQuizAttempt(attempt);
        
        // Show results
        showResults();
    }
    
    private void showResults() {
        quizContainer.setVisible(false);
        resultsContainer.setVisible(true);
        
        double percentage = questions.size() > 0 ? (double) score / questions.size() * 100 : 0;
        
        scoreLabel.setText(String.format(
            "Quiz Completed!\n\nScore: %d / %d (%.1f%%)\n\n%s",
            score, questions.size(), percentage,
            getPerformanceMessage(percentage)
        ));
    }
    
    private String getPerformanceMessage(double percentage) {
        if (percentage >= 90) return "Excellent work! 🎉";
        if (percentage >= 80) return "Great job! 👏";
        if (percentage >= 70) return "Good effort! 👍";
        if (percentage >= 60) return "Not bad, keep practicing! 📚";
        return "Keep studying and try again! 💪";
    }
    
    @FXML
    private void handleBackToDashboard() {
        SceneManager.clearCache(); // Refresh dashboard data
        SceneManager.switchScene("dashboard");
    }
    
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
        
        SceneManager.switchScene("dashboard");
    }
}
