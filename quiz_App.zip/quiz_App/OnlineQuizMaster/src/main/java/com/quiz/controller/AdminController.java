package com.quiz.controller;

import com.quiz.model.Question;
import com.quiz.model.Quiz;
import com.quiz.service.QuizService;
import com.quiz.util.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Controller for the admin panel
 */
public class AdminController {
    
    @FXML private TextField quizTitleField;
    @FXML private TextArea quizDescriptionArea;
    @FXML private TextField quizCategoryField;
    @FXML private ListView<Quiz> existingQuizzesListView;
    @FXML private Button createQuizButton;
    @FXML private Button deleteQuizButton;
    @FXML private Button backToDashboardButton;
    
    // Question creation fields
    @FXML private TextArea questionTextArea;
    @FXML private TextField optionAField;
    @FXML private TextField optionBField;
    @FXML private TextField optionCField;
    @FXML private TextField optionDField;
    @FXML private ComboBox<String> correctAnswerComboBox;
    @FXML private TextField pointsField;
    @FXML private Button addQuestionButton;
    @FXML private ListView<String> questionsListView;
    @FXML private Label statusLabel;
    
    private QuizService quizService = new QuizService();
    private List<Question> pendingQuestions = new ArrayList<>();
    private int currentQuizId = -1;
    
    @FXML
    private void initialize() {
        if (!LoginController.currentUser.isAdmin()) {
            showError("Access denied. Admin privileges required.");
            SceneManager.switchScene("dashboard");
            return;
        }
        
        setupUI();
        loadExistingQuizzes();
        statusLabel.setVisible(false);
    }
    
    private void setupUI() {
        correctAnswerComboBox.setItems(FXCollections.observableArrayList("A", "B", "C", "D"));
        correctAnswerComboBox.getSelectionModel().selectFirst();
        
        pointsField.setText("1");
        
        existingQuizzesListView.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> deleteQuizButton.setDisable(newValue == null)
        );
        
        deleteQuizButton.setDisable(true);
    }
    
    private void loadExistingQuizzes() {
        List<Quiz> quizzes = quizService.getAllQuizzes();
        existingQuizzesListView.setItems(FXCollections.observableArrayList(quizzes));
        
        if (quizzes.isEmpty()) {
            existingQuizzesListView.setPlaceholder(new Label("No quizzes created yet"));
        }
    }
    
    @FXML
    private void handleCreateQuiz() {
        String title = quizTitleField.getText().trim();
        String description = quizDescriptionArea.getText().trim();
        String category = quizCategoryField.getText().trim();
        
        if (title.isEmpty() || category.isEmpty()) {
            showStatus("Please enter quiz title and category", false);
            return;
        }
        
        if (pendingQuestions.isEmpty()) {
            showStatus("Please add at least one question", false);
            return;
        }
        
        // Create quiz
        Quiz quiz = new Quiz(title, description, category, LoginController.currentUser.getId());
        int quizId = quizService.createQuiz(quiz);
        
        if (quizId > 0) {
            // Add all pending questions
            boolean allQuestionsAdded = true;
            for (Question question : pendingQuestions) {
                question.setQuizId(quizId);
                if (!quizService.addQuestion(question)) {
                    allQuestionsAdded = false;
                }
            }
            
            if (allQuestionsAdded) {
                showStatus("Quiz created successfully with " + pendingQuestions.size() + " questions!", true);
                clearForm();
                loadExistingQuizzes();
            } else {
                showStatus("Quiz created but some questions failed to save", false);
            }
        } else {
            showStatus("Failed to create quiz", false);
        }
    }
    
    @FXML
    private void handleAddQuestion() {
        String questionText = questionTextArea.getText().trim();
        String optionA = optionAField.getText().trim();
        String optionB = optionBField.getText().trim();
        String optionC = optionCField.getText().trim();
        String optionD = optionDField.getText().trim();
        String correctAnswer = correctAnswerComboBox.getValue();
        String pointsText = pointsField.getText().trim();
        
        if (questionText.isEmpty() || optionA.isEmpty() || optionB.isEmpty() || 
            optionC.isEmpty() || optionD.isEmpty() || correctAnswer == null) {
            showStatus("Please fill in all question fields", false);
            return;
        }
        
        int points;
        try {
            points = Integer.parseInt(pointsText);
            if (points <= 0) {
                showStatus("Points must be a positive number", false);
                return;
            }
        } catch (NumberFormatException e) {
            showStatus("Please enter a valid number for points", false);
            return;
        }
        
        Question question = new Question(
            -1, // Quiz ID will be set when quiz is created
            questionText,
            optionA, optionB, optionC, optionD,
            correctAnswer.charAt(0),
            points
        );
        
        pendingQuestions.add(question);
        updateQuestionsDisplay();
        clearQuestionForm();
        showStatus("Question added! Total questions: " + pendingQuestions.size(), true);
    }
    
    private void updateQuestionsDisplay() {
        List<String> questionDisplays = new ArrayList<>();
        for (int i = 0; i < pendingQuestions.size(); i++) {
            Question q = pendingQuestions.get(i);
            questionDisplays.add((i + 1) + ". " + q.getQuestionText() + 
                               " (Correct: " + q.getCorrectAnswer() + ", Points: " + q.getPoints() + ")");
        }
        questionsListView.setItems(FXCollections.observableArrayList(questionDisplays));
    }
    
    @FXML
    private void handleDeleteQuiz() {
        Quiz selectedQuiz = existingQuizzesListView.getSelectionModel().getSelectedItem();
        if (selectedQuiz == null) {
            return;
        }
        
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Delete Quiz");
        confirmation.setHeaderText("Delete Quiz: " + selectedQuiz.getTitle());
        confirmation.setContentText("Are you sure you want to delete this quiz? This action cannot be undone.");
        
        confirmation.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                boolean success = quizService.deleteQuiz(selectedQuiz.getId());
                if (success) {
                    showStatus("Quiz deleted successfully", true);
                    loadExistingQuizzes();
                } else {
                    showStatus("Failed to delete quiz", false);
                }
            }
        });
    }
    
    @FXML
    private void handleBackToDashboard() {
        SceneManager.switchScene("dashboard");
    }
    
    private void clearForm() {
        quizTitleField.clear();
        quizDescriptionArea.clear();
        quizCategoryField.clear();
        clearQuestionForm();
        pendingQuestions.clear();
        questionsListView.getItems().clear();
    }
    
    private void clearQuestionForm() {
        questionTextArea.clear();
        optionAField.clear();
        optionBField.clear();
        optionCField.clear();
        optionDField.clear();
        correctAnswerComboBox.getSelectionModel().selectFirst();
        pointsField.setText("1");
    }
    
    private void showStatus(String message, boolean isSuccess) {
        statusLabel.setText(message);
        statusLabel.setStyle(isSuccess ? "-fx-text-fill: green;" : "-fx-text-fill: red;");
        statusLabel.setVisible(true);
    }
    
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
