package com.quiz.service;

import com.quiz.model.Question;
import com.quiz.model.Quiz;
import com.quiz.model.QuizAttempt;
import com.quiz.util.DatabaseUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Service class for quiz-related database operations
 */
public class QuizService {
    
    /**
     * Create a new quiz
     */
    public int createQuiz(Quiz quiz) {
        String sql = "INSERT INTO quizzes (title, description, category, created_by) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, quiz.getTitle());
            pstmt.setString(2, quiz.getDescription());
            pstmt.setString(3, quiz.getCategory());
            pstmt.setInt(4, quiz.getCreatedBy());
            
            int result = pstmt.executeUpdate();
            if (result > 0) {
                ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error creating quiz: " + e.getMessage());
        }
        
        return -1;
    }
    
    /**
     * Add a question to a quiz
     */
    public boolean addQuestion(Question question) {
        String sql = "INSERT INTO questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_answer, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, question.getQuizId());
            pstmt.setString(2, question.getQuestionText());
            pstmt.setString(3, question.getOptionA());
            pstmt.setString(4, question.getOptionB());
            pstmt.setString(5, question.getOptionC());
            pstmt.setString(6, question.getOptionD());
            pstmt.setString(7, String.valueOf(question.getCorrectAnswer()));
            pstmt.setInt(8, question.getPoints());
            
            int result = pstmt.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("Error adding question: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get all quizzes
     */
    public List<Quiz> getAllQuizzes() {
        List<Quiz> quizzes = new ArrayList<>();
        String sql = "SELECT * FROM quizzes ORDER BY created_at DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                Quiz quiz = new Quiz();
                quiz.setId(rs.getInt("id"));
                quiz.setTitle(rs.getString("title"));
                quiz.setDescription(rs.getString("description"));
                quiz.setCategory(rs.getString("category"));
                quiz.setCreatedBy(rs.getInt("created_by"));
                
                Timestamp timestamp = rs.getTimestamp("created_at");
                if (timestamp != null) {
                    quiz.setCreatedAt(timestamp.toLocalDateTime());
                }
                
                quizzes.add(quiz);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all quizzes: " + e.getMessage());
        }
        
        return quizzes;
    }
    
    /**
     * Get questions for a specific quiz
     */
    public List<Question> getQuizQuestions(int quizId) {
        List<Question> questions = new ArrayList<>();
        String sql = "SELECT * FROM questions WHERE quiz_id = ? ORDER BY id";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, quizId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Question question = new Question();
                question.setId(rs.getInt("id"));
                question.setQuizId(rs.getInt("quiz_id"));
                question.setQuestionText(rs.getString("question_text"));
                question.setOptionA(rs.getString("option_a"));
                question.setOptionB(rs.getString("option_b"));
                question.setOptionC(rs.getString("option_c"));
                question.setOptionD(rs.getString("option_d"));
                question.setCorrectAnswer(rs.getString("correct_answer").charAt(0));
                question.setPoints(rs.getInt("points"));
                
                questions.add(question);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting quiz questions: " + e.getMessage());
        }
        
        return questions;
    }
    
    /**
     * Save quiz attempt
     */
    public boolean saveQuizAttempt(QuizAttempt attempt) {
        String sql = "INSERT INTO quiz_attempts (user_id, quiz_id, score, total_questions) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, attempt.getUserId());
            pstmt.setInt(2, attempt.getQuizId());
            pstmt.setInt(3, attempt.getScore());
            pstmt.setInt(4, attempt.getTotalQuestions());
            
            int result = pstmt.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("Error saving quiz attempt: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get user's quiz history
     */
    public List<QuizAttempt> getUserQuizHistory(int userId) {
        List<QuizAttempt> attempts = new ArrayList<>();
        String sql = """
            SELECT qa.*, q.title as quiz_title 
            FROM quiz_attempts qa 
            JOIN quizzes q ON qa.quiz_id = q.id 
            WHERE qa.user_id = ? 
            ORDER BY qa.completed_at DESC
            """;
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                QuizAttempt attempt = new QuizAttempt();
                attempt.setId(rs.getInt("id"));
                attempt.setUserId(rs.getInt("user_id"));
                attempt.setQuizId(rs.getInt("quiz_id"));
                attempt.setScore(rs.getInt("score"));
                attempt.setTotalQuestions(rs.getInt("total_questions"));
                attempt.setQuizTitle(rs.getString("quiz_title"));
                
                Timestamp timestamp = rs.getTimestamp("completed_at");
                if (timestamp != null) {
                    attempt.setCompletedAt(timestamp.toLocalDateTime());
                }
                
                attempts.add(attempt);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting user quiz history: " + e.getMessage());
        }
        
        return attempts;
    }
    
    /**
     * Get leaderboard data
     */
    public List<QuizAttempt> getLeaderboard() {
        List<QuizAttempt> leaderboard = new ArrayList<>();
        String sql = """
            SELECT qa.*, q.title as quiz_title, u.username 
            FROM quiz_attempts qa 
            JOIN quizzes q ON qa.quiz_id = q.id 
            JOIN users u ON qa.user_id = u.id 
            ORDER BY qa.score DESC, qa.completed_at ASC 
            LIMIT 50
            """;
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                QuizAttempt attempt = new QuizAttempt();
                attempt.setId(rs.getInt("id"));
                attempt.setUserId(rs.getInt("user_id"));
                attempt.setQuizId(rs.getInt("quiz_id"));
                attempt.setScore(rs.getInt("score"));
                attempt.setTotalQuestions(rs.getInt("total_questions"));
                attempt.setQuizTitle(rs.getString("quiz_title"));
                attempt.setUsername(rs.getString("username"));
                
                Timestamp timestamp = rs.getTimestamp("completed_at");
                if (timestamp != null) {
                    attempt.setCompletedAt(timestamp.toLocalDateTime());
                }
                
                leaderboard.add(attempt);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting leaderboard: " + e.getMessage());
        }
        
        return leaderboard;
    }
    
    /**
     * Delete a quiz and all its questions
     */
    public boolean deleteQuiz(int quizId) {
        String sql = "DELETE FROM quizzes WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, quizId);
            int result = pstmt.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting quiz: " + e.getMessage());
            return false;
        }
    }
}
