package com.quiz.model;

import java.time.LocalDateTime;

/**
 * QuizAttempt model class representing a user's attempt at a quiz
 */
public class QuizAttempt {
    private int id;
    private int userId;
    private int quizId;
    private int score;
    private int totalQuestions;
    private LocalDateTime completedAt;
    private String quizTitle; // For display purposes
    private String username; // For display purposes
    
    public QuizAttempt() {}
    
    public QuizAttempt(int userId, int quizId, int score, int totalQuestions) {
        this.userId = userId;
        this.quizId = quizId;
        this.score = score;
        this.totalQuestions = totalQuestions;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public int getQuizId() { return quizId; }
    public void setQuizId(int quizId) { this.quizId = quizId; }
    
    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }
    
    public int getTotalQuestions() { return totalQuestions; }
    public void setTotalQuestions(int totalQuestions) { this.totalQuestions = totalQuestions; }
    
    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }
    
    public String getQuizTitle() { return quizTitle; }
    public void setQuizTitle(String quizTitle) { this.quizTitle = quizTitle; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public double getPercentage() {
        return totalQuestions > 0 ? (double) score / totalQuestions * 100 : 0;
    }
}
