package com.quiz.model;

import java.time.LocalDateTime;

/**
 * Quiz model class representing a quiz in the application
 */
public class Quiz {
    private int id;
    private String title;
    private String description;
    private String category;
    private int createdBy;
    private LocalDateTime createdAt;
    
    public Quiz() {}
    
    public Quiz(String title, String description, String category, int createdBy) {
        this.title = title;
        this.description = description;
        this.category = category;
        this.createdBy = createdBy;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    
    public int getCreatedBy() { return createdBy; }
    public void setCreatedBy(int createdBy) { this.createdBy = createdBy; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    @Override
    public String toString() {
        return title + " (" + category + ")";
    }
}
